/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ice_task_five;

import javax.swing.JOptionPane;
import java.util.*;

public class Ice_task_five {

    public static void main(String[] args) {
        //var
        String name1, name2, name3;
        boolean flagMTN = false;
        boolean flagCC = false;
        boolean flagVodacom = false;
        int num1, num2, num3;
        String display1, display2, display3;
        //begin
        name1 = JOptionPane.showInputDialog("Please enter employee 1");
        name2 = JOptionPane.showInputDialog("Please enter employee 2");
        name3 = JOptionPane.showInputDialog("Please enter employee 3");
        // if (n < 10 && n > 29) {}
        Random dice = new Random();
        num1 = dice.nextInt(31);
        num2 = dice.nextInt(31);
        num3 = dice.nextInt(31);

        if (num1 <= 10 && flagMTN == false) {
            flagMTN = true;
            display1 = name1 + "is with MTN";
        } else if (num1 > 10 && num1 <= 20 && flagCC == false) {
            flagCC = true;
            display1 = name1 + "is with CC";
        } else if (num1 > 20 && num1 <= 30 && flagVodacom == false) {
            flagVodacom = true;
            display1 = name1 + "is with Vodacom";
        }

        if (num2 <= 10 && flagMTN == false) {
            flagMTN = true;
            display2 = name2 + "is with MTN";
        } else if (num2 > 10 && num2 <= 20 && flagCC == false) {
            flagCC = true;
            display2 = name2 + "is with CC";
        } else if (num2 > 20 && num2 <= 30 && flagVodacom == false) {
            flagVodacom = true;
            display2 = name2 + "is with Vodacom";
        }

        if (num3 <= 10 && flagMTN == false) {
            flagMTN = true;
            display3 = name3 + "is with MTN";
        } else if (num3 > 10 && num3 <= 20 && flagCC == false) {
            flagCC = true;
            display3 = name3 + "is with CC";
        } else if (num3 > 20 && num3 <= 30 && flagVodacom == false) {
            flagVodacom = true;
            display3 = name3 + "is with Vodacom";
        }
        
        
    }

}
